#!/usr/bin/env python3
"""
每小时进度报告发送脚本 - 11:00 AM
目标邮箱: 2355715633@qq.com
"""

import os
import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import sys

def load_config():
    """加载邮件配置"""
    config = {
        'smtp_server': os.environ.get('SMTP_SERVER', 'smtp.qq.com'),
        'smtp_port': int(os.environ.get('SMTP_PORT', 587)),
        'smtp_username': os.environ.get('SMTP_USERNAME', '2355715633@qq.com'),
        'smtp_password': os.environ.get('SMTP_PASSWORD', ''),
        'sender_email': os.environ.get('SENDER_EMAIL', '2355715633@qq.com'),
        'receiver_email': os.environ.get('RECEIVER_EMAIL', '2355715633@qq.com'),
        'subject_prefix': os.environ.get('SUBJECT_PREFIX', '[OpenClaw] 每小时进度报告')
    }
    
    if not config['smtp_password']:
        print("错误: SMTP_PASSWORD环境变量未设置")
        print("请设置SMTP_PASSWORD环境变量:")
        print("  export SMTP_PASSWORD='your-smtp-password'")
        return None
    
    return config

def create_email(config):
    """创建邮件内容"""
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    report_time = "2026-03-29 11:00 AM (欧洲/罗马时间)"
    
    # 创建邮件对象
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f"{config['subject_prefix']} - 11:00 AM"
    msg['From'] = config['sender_email']
    msg['To'] = config['receiver_email']
    msg['Date'] = current_time
    
    # 纯文本内容
    text_content = f"""
每小时进度报告 - 11:00 AM (欧洲/罗马时间)
=========================================

报告时间: {report_time}
生成时间: {current_time}

📊 报告概览
----------
项目状态: 正常运行，开发活跃
整体评估: ✅ 良好

🖥️ 服务状态
-----------
后端服务: ✅ 运行正常 (端口3001)
前端服务: ✅ 运行正常 (端口5173)
TypeScript编译: ✅ 无错误

⏰ 开发时间
----------
本时段开发: 约80分钟
今日累计: 约340分钟 (5.7小时)
目标完成度: 56.7%

📈 代码提交
----------
本时段提交: 11次
今日总提交: 38次
心跳检查: 35分钟 (超额完成)

💻 系统资源
----------
CPU使用率: 32.65% (负载: 4.83)
内存使用率: 95.8% ⚠️ 需要关注
磁盘使用率: 55% (正常)

🚨 关键风险
----------
1. 内存使用率95.8%，接近极限
2. 系统负载较高 (4.83)
3. 16个安全漏洞需要处理

📋 下一步计划
----------
1. 内存优化和负载监控
2. 解决依赖兼容性问题
3. 验证核心功能正常工作

---
详细报告请查看HTML版本或附件。
报告生成系统: OpenClaw
"""
    
    # HTML内容
    with open('hourly_report_email_1100.html', 'r', encoding='utf-8') as f:
        html_content = f.read()
    
    # 添加文本和HTML版本
    msg.attach(MIMEText(text_content, 'plain', 'utf-8'))
    msg.attach(MIMEText(html_content, 'html', 'utf-8'))
    
    # 添加附件
    attachments = [
        'hourly_report_summary_1100.md',
        'hourly_report_email_content_1100.txt'
    ]
    
    for attachment in attachments:
        if os.path.exists(attachment):
            with open(attachment, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header(
                    'Content-Disposition',
                    f'attachment; filename="{os.path.basename(attachment)}"'
                )
                msg.attach(part)
                print(f"已添加附件: {attachment}")
    
    return msg

def send_email(config, msg):
    """发送邮件"""
    try:
        # 创建SSL上下文
        context = ssl.create_default_context()
        
        # 连接到SMTP服务器
        print(f"连接到SMTP服务器: {config['smtp_server']}:{config['smtp_port']}")
        server = smtplib.SMTP(config['smtp_server'], config['smtp_port'])
        server.ehlo()
        server.starttls(context=context)
        server.ehlo()
        
        # 登录
        print(f"登录到邮箱: {config['smtp_username']}")
        server.login(config['smtp_username'], config['smtp_password'])
        
        # 发送邮件
        print(f"发送邮件到: {config['receiver_email']}")
        server.send_message(msg)
        
        # 关闭连接
        server.quit()
        print("✅ 邮件发送成功!")
        return True
        
    except Exception as e:
        print(f"❌ 邮件发送失败: {str(e)}")
        return False

def save_email_locally(msg):
    """将邮件保存到本地文件"""
    try:
        filename = f"hourly_report_email_ready_{datetime.now().strftime('%H%M')}.eml"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(msg.as_string())
        print(f"📁 邮件已保存到本地文件: {filename}")
        print(f"手动发送命令: sendmail 2355715633@qq.com < {filename}")
        return filename
    except Exception as e:
        print(f"❌ 保存邮件到本地失败: {str(e)}")
        return None

def main():
    """主函数"""
    print("=" * 60)
    print("每小时进度报告发送脚本 - 11:00 AM")
    print("=" * 60)
    
    # 加载配置
    config = load_config()
    
    # 创建邮件
    print("📧 创建邮件内容...")
    msg = create_email(config) if config else create_email({
        'smtp_server': 'smtp.qq.com',
        'smtp_port': 587,
        'smtp_username': '2355715633@qq.com',
        'smtp_password': '',
        'sender_email': '2355715633@qq.com',
        'receiver_email': '2355715633@qq.com',
        'subject_prefix': '[OpenClaw] 每小时进度报告'
    })
    
    if not msg:
        print("❌ 创建邮件失败")
        return False
    
    # 如果配置了SMTP密码，尝试发送邮件
    if config and config.get('smtp_password'):
        print("\n🚀 尝试发送邮件...")
        success = send_email(config, msg)
        
        if success:
            print("\n✅ 邮件发送成功!")
        else:
            print("\n⚠️ 自动发送失败，保存邮件到本地...")
            save_email_locally(msg)
    else:
        print("\n⚠️ 未配置SMTP密码，保存邮件到本地...")
        saved_file = save_email_locally(msg)
        if saved_file:
            print(f"\n📋 邮件已保存，手动发送选项:")
            print(f"1. 使用sendmail: sendmail 2355715633@qq.com < {saved_file}")
            print(f"2. 使用mail命令: cat hourly_report_email_content_1100.txt | mail -s '每小时进度报告 - 11:00 AM' 2355715633@qq.com")
            print(f"3. 在浏览器中查看: open hourly_report_email_1100.html")
            print(f"\n📝 配置SMTP密码后自动发送:")
            print(f"  export SMTP_PASSWORD='your-smtp-password'")
            print(f"  ./send_report_simple_1100.sh")
    
    print("\n" + "=" * 60)
    print("脚本执行完成")
    print("=" * 60)
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)