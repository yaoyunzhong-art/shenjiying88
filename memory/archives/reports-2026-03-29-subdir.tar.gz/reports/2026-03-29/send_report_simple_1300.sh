#!/bin/bash
# 每小时进度报告发送脚本 - 13:00

set -e

echo "📊 开始发送每小时进度报告 - 13:00"
echo "=================================================="

# 检查必要的文件
REQUIRED_FILES=(
    "hourly_report_email_content_1300.txt"
    "hourly_report_email_1300.html"
    "hourly_report_summary_1300.md"
    "send_hourly_report_1300.py"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "❌ 错误: 缺少必要文件 $file"
        exit 1
    fi
done

echo "✅ 所有必要文件存在"

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: 未找到python3"
    exit 1
fi

echo "🐍 Python3版本: $(python3 --version)"

# 检查环境变量
if [ -z "$SMTP_PASSWORD" ]; then
    echo "⚠️ 警告: 未设置SMTP_PASSWORD环境变量"
    echo "   邮件将保存为文件供手动发送"
    echo "   设置环境变量: export SMTP_PASSWORD='your-password'"
    echo ""
    echo "📧 执行Python脚本进行邮件发送..."
    python3 send_hourly_report_1300.py
else
    echo "✅ SMTP_PASSWORD环境变量已设置"
    echo "📧 执行Python脚本进行邮件发送..."
    python3 send_hourly_report_1300.py
fi

# 检查发送结果
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 脚本执行完成"
    echo "=================================================="
    
    # 检查是否生成了.eml文件
    if ls hourly_report_email_ready_*.eml 1> /dev/null 2>&1; then
        EML_FILE=$(ls hourly_report_email_ready_*.eml | head -1)
        echo "📧 邮件已保存为: $EML_FILE"
        echo "📋 手动发送命令:"
        echo "   sendmail 2355715633@qq.com < $EML_FILE"
    fi
else
    echo ""
    echo "❌ 脚本执行失败"
    echo "=================================================="
    exit 1
fi

echo ""
echo "📊 报告文件列表:"
echo "  - hourly_report_summary_1300.md (详细报告)"
echo "  - hourly_report_email_content_1300.txt (纯文本邮件)"
echo "  - hourly_report_email_1300.html (HTML邮件)"
echo "  - send_hourly_report_1300.py (发送脚本)"
echo ""
echo "🕐 下次报告时间: 14:00"
echo "=================================================="