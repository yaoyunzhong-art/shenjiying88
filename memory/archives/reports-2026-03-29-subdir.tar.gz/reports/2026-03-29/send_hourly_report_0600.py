#!/usr/bin/env python3
"""
每小时进度报告发送脚本 - 2026-03-29 06:00
发送进度报告到指定邮箱
"""

import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from datetime import datetime
import sys

def read_file_content(file_path):
    """读取文件内容"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"读取文件失败 {file_path}: {e}")
        return None

def send_email_report():
    """发送邮件报告"""
    # 邮件配置
    sender_email = "openclaw@yaoyunzhong.com"  # 发送方邮箱
    receiver_email = "2355715633@qq.com"      # 接收方邮箱
    smtp_server = "smtp.gmail.com"           # SMTP服务器
    smtp_port = 587                          # SMTP端口
    
    # 从环境变量获取密码
    smtp_password = os.environ.get("SMTP_PASSWORD")
    if not smtp_password:
        print("错误: 未设置SMTP_PASSWORD环境变量")
        print("请设置环境变量: export SMTP_PASSWORD='your-app-password'")
        return False
    
    # 读取报告内容
    html_content = read_file_content("hourly_report_email_0600.html")
    text_content = read_file_content("hourly_report_email_content_0600.txt")
    
    if not html_content or not text_content:
        print("错误: 无法读取报告内容")
        return False
    
    # 创建邮件
    msg = MIMEMultipart('alternative')
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = Header(f"🚀 每小时进度报告 - {datetime.now().strftime('%Y-%m-%d %H:%M')} (欧洲/罗马时间)", 'utf-8')
    
    # 添加文本版本
    text_part = MIMEText(text_content, 'plain', 'utf-8')
    msg.attach(text_part)
    
    # 添加HTML版本
    html_part = MIMEText(html_content, 'html', 'utf-8')
    msg.attach(html_part)
    
    try:
        # 连接SMTP服务器并发送邮件
        print(f"正在连接SMTP服务器: {smtp_server}:{smtp_port}")
        server = smtplib.SMTP(smtp_server, smtp_port)
        server.starttls()  # 启用TLS加密
        print("正在登录邮箱...")
        server.login(sender_email, smtp_password)
        print("正在发送邮件...")
        server.sendmail(sender_email, receiver_email, msg.as_string())
        server.quit()
        print(f"✅ 邮件发送成功到: {receiver_email}")
        return True
    except Exception as e:
        print(f"❌ 邮件发送失败: {e}")
        return False

def create_send_log():
    """创建发送日志"""
    log_content = f"""每小时进度报告发送日志
=======================
发送时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
报告时间: 2026-03-29 06:00 (欧洲/罗马时间)
目标邮箱: 2355715633@qq.com
发送状态: {'成功' if send_email_report() else '失败'}
报告文件:
  - hourly_report_summary_0600.md
  - hourly_report_email_0600.html
  - hourly_report_email_content_0600.txt
  - send_hourly_report_0600.py
"""
    
    with open("hourly_report_send_0600.log", "w", encoding="utf-8") as f:
        f.write(log_content)
    
    print("\n" + log_content)
    return True

def main():
    """主函数"""
    print("=" * 60)
    print("每小时进度报告发送脚本 - 2026-03-29 06:00")
    print("=" * 60)
    
    # 检查必要的文件
    required_files = [
        "hourly_report_summary_0600.md",
        "hourly_report_email_0600.html", 
        "hourly_report_email_content_0600.txt"
    ]
    
    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print(f"❌ 缺少必要的文件: {missing_files}")
        print("请先生成报告文件再运行发送脚本")
        return False
    
    print("✅ 所有必要文件已就绪")
    print("开始发送邮件报告...")
    
    # 发送邮件并创建日志
    success = create_send_log()
    
    if success:
        print("=" * 60)
        print("✅ 每小时进度报告任务完成")
        print("=" * 60)
    else:
        print("=" * 60)
        print("❌ 每小时进度报告任务失败")
        print("=" * 60)
    
    return success

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)