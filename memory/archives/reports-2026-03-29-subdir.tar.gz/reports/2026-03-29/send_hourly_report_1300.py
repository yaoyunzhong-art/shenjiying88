#!/usr/bin/env python3
"""
每小时进度报告发送脚本 - 13:00
发送到: 2355715633@qq.com
"""

import os
import smtplib
import ssl
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime
import sys

def load_config():
    """加载邮件配置"""
    config = {
        'smtp_server': 'smtp.qq.com',
        'smtp_port': 587,
        'sender_email': '2355715633@qq.com',
        'receiver_email': '2355715633@qq.com',
        'subject': '每小时进度报告 - 13:00 (欧洲/罗马时间)',
    }
    
    # 从环境变量获取密码
    smtp_password = os.environ.get('SMTP_PASSWORD')
    if not smtp_password:
        print("错误: 未设置SMTP_PASSWORD环境变量")
        print("请设置环境变量: export SMTP_PASSWORD='your-qq-email-password'")
        return None
    
    config['smtp_password'] = smtp_password
    return config

def create_email(config):
    """创建邮件内容"""
    # 创建多部分邮件
    msg = MIMEMultipart('alternative')
    msg['From'] = config['sender_email']
    msg['To'] = config['receiver_email']
    msg['Subject'] = config['subject']
    
    # 添加纯文本版本
    with open('hourly_report_email_content_1300.txt', 'r', encoding='utf-8') as f:
        text_content = f.read()
    msg.attach(MIMEText(text_content, 'plain', 'utf-8'))
    
    # 添加HTML版本
    with open('hourly_report_email_1300.html', 'r', encoding='utf-8') as f:
        html_content = f.read()
    msg.attach(MIMEText(html_content, 'html', 'utf-8'))
    
    # 添加详细报告作为附件
    with open('hourly_report_summary_1300.md', 'r', encoding='utf-8') as f:
        report_content = f.read()
    
    attachment = MIMEBase('application', 'octet-stream')
    attachment.set_payload(report_content.encode('utf-8'))
    encoders.encode_base64(attachment)
    attachment.add_header(
        'Content-Disposition',
        f'attachment; filename="hourly_report_1300_{datetime.now().strftime("%Y%m%d_%H%M")}.md"'
    )
    msg.attach(attachment)
    
    return msg

def send_email(config, msg):
    """发送邮件"""
    try:
        # 创建安全SSL上下文
        context = ssl.create_default_context()
        
        # 连接到SMTP服务器
        with smtplib.SMTP(config['smtp_server'], config['smtp_port']) as server:
            server.starttls(context=context)
            server.login(config['sender_email'], config['smtp_password'])
            server.send_message(msg)
        
        print(f"✅ 邮件发送成功到 {config['receiver_email']}")
        return True
        
    except smtplib.SMTPAuthenticationError:
        print("❌ SMTP认证失败: 请检查邮箱和密码")
        print("注意: QQ邮箱需要使用授权码，而不是登录密码")
        return False
    except smtplib.SMTPException as e:
        print(f"❌ SMTP错误: {e}")
        return False
    except Exception as e:
        print(f"❌ 发送邮件时出错: {e}")
        return False

def save_email_for_manual_sending(msg):
    """保存邮件内容供手动发送"""
    eml_filename = f"hourly_report_email_ready_{datetime.now().strftime('%H%M')}.eml"
    
    with open(eml_filename, 'w', encoding='utf-8') as f:
        f.write(msg.as_string())
    
    print(f"📧 邮件已保存为: {eml_filename}")
    print("📋 手动发送命令:")
    print(f"  sendmail {config['receiver_email']} < {eml_filename}")
    print(" 或使用邮件客户端导入此.eml文件")
    
    return eml_filename

def main():
    """主函数"""
    print("📊 开始发送每小时进度报告 - 13:00")
    print("=" * 50)
    
    # 加载配置
    config = load_config()
    if not config:
        print("❌ 配置加载失败，退出")
        sys.exit(1)
    
    # 创建邮件
    print("📝 创建邮件内容...")
    msg = create_email(config)
    
    # 尝试发送邮件
    print("📤 尝试发送邮件...")
    success = send_email(config, msg)
    
    if not success:
        print("⚠️ 自动发送失败，保存邮件供手动发送")
        eml_file = save_email_for_manual_sending(msg)
        
        print("\n🔧 故障排除建议:")
        print("1. 确保设置了正确的SMTP_PASSWORD环境变量")
        print("2. QQ邮箱需要使用授权码而不是登录密码")
        print("3. 检查网络连接和防火墙设置")
        print("4. 确认QQ邮箱已开启SMTP服务")
        print(f"5. 手动发送: sendmail {config['receiver_email']} < {eml_file}")
    else:
        print("\n✅ 每小时进度报告发送完成")
        print(f"   时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   收件人: {config['receiver_email']}")
        print(f"   主题: {config['subject']}")
    
    print("=" * 50)

if __name__ == "__main__":
    main()