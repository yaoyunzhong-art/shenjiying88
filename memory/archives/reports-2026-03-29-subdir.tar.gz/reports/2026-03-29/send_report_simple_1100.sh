#!/bin/bash

# 每小时进度报告发送脚本 - 11:00 AM
# 简化版本，用于快速发送报告

set -e

echo "========================================"
echo "每小时进度报告发送脚本 - 11:00 AM"
echo "========================================"

# 检查必要文件
REQUIRED_FILES=(
    "hourly_report_summary_1100.md"
    "hourly_report_email_content_1100.txt"
    "hourly_report_email_1100.html"
    "send_hourly_report_1100.py"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ ! -f "$file" ]; then
        echo "❌ 缺少必要文件: $file"
        exit 1
    fi
done

echo "✅ 所有必要文件都存在"

# 检查Python环境
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3未安装"
    exit 1
fi

echo "🐍 Python3版本: $(python3 --version)"

# 检查SMTP配置
if [ -z "$SMTP_PASSWORD" ]; then
    echo "⚠️  SMTP_PASSWORD环境变量未设置"
    echo ""
    echo "配置方法:"
    echo "1. 设置SMTP密码:"
    echo "   export SMTP_PASSWORD='your-smtp-password'"
    echo ""
    echo "2. 可选的其他配置:"
    echo "   export SMTP_SERVER='smtp.qq.com'"
    echo "   export SMTP_PORT=587"
    echo "   export SMTP_USERNAME='2355715633@qq.com'"
    echo "   export RECEIVER_EMAIL='2355715633@qq.com'"
    echo ""
    echo "3. 运行脚本:"
    echo "   ./send_report_simple_1100.sh"
    echo ""
    
    # 尝试使用默认配置
    echo "尝试使用默认配置发送..."
    export SMTP_SERVER="smtp.qq.com"
    export SMTP_PORT=587
    export SMTP_USERNAME="2355715633@qq.com"
    export RECEIVER_EMAIL="2355715633@qq.com"
    
    if [ -z "$SMTP_PASSWORD" ]; then
        echo "❌ 仍然缺少SMTP_PASSWORD，无法发送邮件"
        echo ""
        echo "备用方案:"
        echo "1. 手动发送邮件内容:"
        echo "   cat hourly_report_email_content_1100.txt | mail -s '每小时进度报告 - 11:00 AM' 2355715633@qq.com"
        echo ""
        echo "2. 保存邮件为文件后手动发送:"
        echo "   python3 send_hourly_report_1100.py"
        echo ""
        exit 1
    fi
fi

# 运行Python发送脚本
echo ""
echo "🚀 开始发送邮件..."
python3 send_hourly_report_1100.py

# 检查发送结果
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 邮件发送流程完成"
    echo ""
    echo "生成的文件:"
    ls -la hourly_report_*1100*
    echo ""
    echo "下次报告时间: 12:00 PM"
else
    echo ""
    echo "❌ 邮件发送失败"
    echo ""
    echo "尝试备用方案:"
    echo "1. 检查邮件内容: cat hourly_report_email_content_1100.txt"
    echo "2. 手动发送:"
    echo "   sendmail 2355715633@qq.com < hourly_report_email_ready_*.eml"
    echo "3. 或使用邮件客户端打开HTML文件: hourly_report_email_1100.html"
fi

echo ""
echo "========================================"
echo "脚本执行完成"
echo "========================================"