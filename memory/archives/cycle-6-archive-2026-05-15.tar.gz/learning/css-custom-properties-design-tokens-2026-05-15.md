# CSS Custom Properties → Design Token 体系实战

> 📚 Cycle 4 学习产出 | 2026-05-15
> 来源: MDN + CSS-Tricks + Element Plus Docs + 设计美工队实践
> 应用: SPORTS ANT 全端设计系统统一

---

## 一、核心概念

### Custom Property = Design Token 天然载体

```css
/* ❌ 传统：硬编码色值散落各处 */
.card { color: #1A1A2E; }
.header { background: #1A1A2E; }

/* ✅ Token：语义化变量，单点修改全局生效 */
:root {
  --color-primary: #1A1A2E;
}
.card { color: var(--color-primary); }
.header { background: var(--color-primary); }
```

**Design Token 三层结构**（关键模式）:

```
原始值 (Raw Value)     →  语义别名 (Semantic)   →  组件引用 (Component)
#1A1A2E               →  --color-brand-bg       →  --sidebar-bg
#E94560               →  --color-brand-cta      →  --btn-primary-bg
```

---

## 二、CSS Custom Properties 关键特性

### 2.1 级联继承 — 主题切换的核心

```css
:root {
  --bg-color: #FFFFFF;
  --text-color: #1A1A2E;
}

/* 暗色模式：在更高优先级作用域覆盖 */
html[data-theme="dark"] {
  --bg-color: #0F0F1A;
  --text-color: #E4E7ED;
}

/* 所有组件自动继承，无需改任何一行代码 */
.card { background: var(--bg-color); color: var(--text-color); }
```

**关键洞察**: 只需在 `html` 层切换一组变量，即可实现全局主题切换 —— 这就是"写一次，到处生效"的设计 token 威力。

### 2.2 var() 的 Fallback 机制

```css
/* 第二个参数是 fallback：token 未定义时使用 */
color: var(--custom-color, #1A1A2E);

/* 支持嵌套 fallback */
color: var(--token-a, var(--token-b, #000));
```

**实践建议**: 给所有 token 设定 fallback = 设计系统的默认值，确保"即使用旧的 CSS 文件版本也能正常渲染"。

### 2.3 @property — 类型约束 + 动画支持

```css
@property --kpi-value {
  syntax: '<number>';
  inherits: true;
  initial-value: 0;
}

/* 有了类型，CSS 动画才能 work */
@keyframes countUp {
  from { --kpi-value: 0; }
  to   { --kpi-value: 12800; }
}
```

**适用场景**: KPI 数字滚动动画、颜色渐变过渡。

### 2.4 JavaScript API — 运行时读写

```ts
// 读取
const primary = getComputedStyle(document.documentElement)
  .getPropertyValue('--color-primary');

// 修改（触发全局重绘）
document.documentElement.style
  .setProperty('--color-primary', '#FF0000');

// 删除
document.documentElement.style
  .removeProperty('--color-primary');
```

**适用场景**: 租户个性化品牌色、运行时换肤。

---

## 三、Element Plus 主题集成模式

### 3.1 双轨制：SCSS Variables + CSS Variables

Element Plus v2.2+ 同时支持两套变量系统：

| 方式 | 编译时 | 运行时 | 适用 |
|------|--------|--------|------|
| SCSS @forward | 需重新编译 | ❌ | 固定品牌色 |
| CSS var(--el-*) | ✅ | ✅ | 动态换肤/暗色模式 |

```css
/* 运行时覆盖 Element Plus 主色 */
:root {
  --el-color-primary: #E94560; /* 覆盖默认蓝→霓虹红 */
  --el-border-radius-base: 6px;
}
```

### 3.2 暗色模式 — 一行 CSS 搞定

```ts
// 入口 main.ts
import 'element-plus/theme-chalk/dark/css-vars.css';
```

```html
<!-- 切换只需 toggle class -->
<html class="dark"> <!-- 暗色 -->
<html class="">      <!-- 亮色 -->
```

**覆盖 Element 暗色变量**:
```css
html.dark {
  --el-bg-color: #0F0F1A;       /* 覆盖默认暗色背景 */
  --el-fill-color-blank: #16213E; /* 卡片背景 */
}
```

### 3.3 组件级 token 隔离

```css
/* 只影响 Tag 组件，不影响其他 */
.custom-section {
  --el-tag-bg-color: var(--color-accent);
  --el-tag-text-color: #FFF;
}
```

**最佳实践**: 用 scope class 而非 `:root` 限制覆盖范围 → 性能更好（局部重绘）+ 更安全。

---

## 四、SPORTS ANT 设计 Token 架构

### 4.1 Token 分层（三层架构）

```
L1: Primitive Tokens（基础色板）
  --color-blue-500: #0F3460;
  --color-red-500:  #E94560;
  …10级色阶 × 5色系 = 50个基础token

L2: Semantic Tokens（语义别名）
  --color-brand-primary: var(--color-blue-900);  /* #1A1A2E */
  --color-brand-cta:      var(--color-red-500);  /* #E94560 */
  --color-brand-accent:   var(--color-blue-500); /* #0F3460 */
  --color-semantic-success: #10B981;
  --color-semantic-warning: #F59E0B;
  --color-semantic-error:   #EF4444;

L3: Component Tokens（组件级）
  --sidebar-bg:        var(--color-brand-primary);
  --sidebar-text:      var(--color-text-inverse);
  --btn-primary-bg:    var(--color-brand-cta);
  --btn-primary-hover: var(--color-red-400);
  --card-bg:           var(--color-surface);
  --input-border:      var(--color-border);
```

### 4.2 亮/暗双主题（CSS 实现）

```css
/* light.css — 默认主题 */
:root,
[data-theme="light"] {
  --color-surface:    #FFFFFF;
  --color-bg:         #F5F7FA;
  --color-border:     #E4E7ED;
  --color-text:       #1A1A2E;
  --color-text-secondary: #909399;
}

/* dark.css — 暗色覆盖 */
[data-theme="dark"] {
  --color-surface:    #16213E;
  --color-bg:         #0F0F1A;
  --color-border:     #2A2A4A;
  --color-text:       #E4E7ED;
  --color-text-secondary: #909399;
}

/* 所有组件代码只写 var() 引用，不关心具体颜色值 */
.card {
  background: var(--color-surface);
  color: var(--color-text);
  border: 1px solid var(--color-border);
}
```

### 4.3 文件结构设计

```
packages/shared-styles/
├── design-tokens.css          ← L1 原始 + L2 语义 token
├── theme-light.css            ← L2 亮色覆盖
├── theme-dark.css             ← L2 暗色覆盖
├── component-tokens.css       ← L3 组件 token
├── theme-switch.ts            ← 主题切换逻辑 + localStorage
├── responsive.css             ← 已有：响应式断点
└── index.css                  ← 汇总 @import
```

---

## 五、主题切换实现方案（Production-ready）

### 5.1 切换逻辑

```ts
// packages/shared-styles/theme-switch.ts
type Theme = 'light' | 'dark' | 'auto';

const STORAGE_KEY = 'sports-ant-theme';

export function getTheme(): Theme {
  return (localStorage.getItem(STORAGE_KEY) as Theme) || 'light';
}

export function setTheme(theme: Theme) {
  localStorage.setItem(STORAGE_KEY, theme);
  applyTheme(theme);
}

function applyTheme(theme: Theme) {
  const html = document.documentElement;
  
  if (theme === 'auto') {
    // 跟随系统偏好
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
    theme = prefersDark.matches ? 'dark' : 'light';
    
    // 监听系统主题变化
    prefersDark.addEventListener('change', (e) => {
      applyTheme(e.matches ? 'dark' : 'light');
    });
  }
  
  html.setAttribute('data-theme', theme);
}
```

### 5.2 Vue Composable 封装

```ts
// composables/useTheme.ts
import { ref, watchEffect } from 'vue';
import { getTheme, setTheme } from 'shared-styles/theme-switch';

export function useTheme() {
  const theme = ref(getTheme());
  
  watchEffect(() => {
    setTheme(theme.value);
  });
  
  const toggle = () => {
    theme.value = theme.value === 'light' ? 'dark' : 'light';
  };
  
  return { theme, toggle };
}
```

---

## 六、防坑指南（关键踩坑记录）

| 坑 | 原因 | 解法 |
|----|------|------|
| Token 无效 | `var()` 只能用在属性值，不能用在属性名/选择器 | 别写 `var(--prop): value` |
| 暗色切换白屏 | CSS 文件加载晚于 HTML 渲染 | `<link>` 放 `<head>` 顶部，加 `blocking="render"` |
| calc() 与 var() | 需要空格 → `calc(var(--space) * 2)` | 别忘了乘号前后空格 |
| Element Plus 变量覆盖不生效 | 优先级不够 | 用 `html.dark` 或组件 scope class |
| 初始闪烁 (FOUC) | JS 切换晚于首屏渲染 | 内联 `<script>` 在 `<head>` 中同步读 localStorage |
| SCSS 变量与 CSS 变量混用 | 编译时 vs 运行时不一致 | CSS var 优先，SCSS 仅用于构建阶段 |

### FOUC 防护最佳实践

```html
<!-- index.html → <head> 第一个 script -->
<script>
  // 同步执行，阻止渲染直到主题应用
  (function() {
    const theme = localStorage.getItem('sports-ant-theme') || 'light';
    document.documentElement.setAttribute('data-theme', theme);
  })();
</script>
```

---

## 七、实施路线图（对应 tasks/trae-cycle-04.md）

| 阶段 | 任务 | 产出 | 耗时 |
|------|------|------|------|
| 1 | L1 Primitive Tokens | `design-tokens.css` (色板/字体/间距/阴影) | 15min |
| 2 | L2 Semantic + Theme | `theme-light.css` + `theme-dark.css` | 10min |
| 3 | L3 Component Tokens | `component-tokens.css` (Admin布局/卡片/按钮) | 10min |
| 4 | 主题切换引擎 | `theme-switch.ts` + `useTheme` composable | 15min |
| 5 | Admin 布局模板 | `AdminLayout.vue` (Sidebar+Header+Content) | 30min |
| 6 | Dashboard KPI 看板 | `DashboardView.vue` 升级 | 20min |
| **总计** | | | **~100min** |

---

## 八、参考资料

- [MDN: Using CSS Custom Properties](https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascading_variables/Using_custom_properties)
- [CSS-Tricks: Complete Guide to Custom Properties](https://css-tricks.com/a-complete-guide-to-custom-properties/)
- [Element Plus: Theming](https://element-plus.org/en-US/guide/theming)
- [Element Plus: Dark Mode](https://element-plus.org/en-US/guide/dark-mode)
- 已有设计规范: `knowledge/design/Sci-Fi-Design-System.md`
- 已有响应式: `packages/shared-styles/responsive.css`
