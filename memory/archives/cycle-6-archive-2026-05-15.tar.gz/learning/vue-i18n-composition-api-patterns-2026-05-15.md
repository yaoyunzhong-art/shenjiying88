# Vue 3 + vue-i18n 组合式API最佳实践

> 学习时间: 2026-05-15 02:00-02:45
> 来源: vue-i18n.intlify.dev 官方文档 (v9/v10/v11), Composition API, Lazy Loading, Optimization 章节

## 1. 组合式API模式 vs Legacy模式

### 1.1 核心切换

vue-i18n v9+ 提供两种API模式。要使用组合式API必须显式设置 `legacy: false`：

```ts
// main.ts - 全局i18n初始化
import { createI18n } from 'vue-i18n'

const i18n = createI18n({
  legacy: false,  // 🔑 必须设为false才能用useI18n()
  locale: 'zh-CN',
  fallbackLocale: 'en',
  messages: {
    'zh-CN': { ... },
    'en': { ... }
  }
})

app.use(i18n)
```

**关键变化**：
- `legacy: true` (默认) → i18n.global 是 `VueI18n` 实例
- `legacy: false` → i18n.global 是 `Composer` 实例
- 模式属性从 `"legacy"` 变为 `"composition"`

### 1.2 useI18n() 基础用法

```vue
<script setup lang="ts">
import { useI18n } from 'vue-i18n'

// 从组合式API获取翻译函数
const { t, d, n, locale, fallbackLocale } = useI18n()

// t() 支持命名参数和列表参数
const namedMsg = t('greeting', { name: 'World' })  // "Hello World!"
const listMsg = t('list', ['item1'])                // 列表插值
</script>

<template>
  <!-- 两种写法等效 -->
  <h1>{{ $t('message.hello') }}</h1>
  <h1>{{ t('message.hello') }}</h1>
</template>
```

**useI18n 返回的 Composer 实例提供**:
- `t(key)` - 消息翻译
- `d(value, format)` - 日期时间格式化
- `n(value, format)` - 数字格式化  
- `rt(key)` - 原始翻译 (无插值)
- `tm(key)` - 返回消息对象
- `locale` - 当前locale (ref)
- `fallbackLocale` - 回退locale

### 1.3 globalInjection 隐式注入

v9.2-beta.34+ 默认 `globalInjection: true`，自动向组件注入：
- `$t`, `$rt`, `$d`, `$n`, `$tm` - 翻译函数
- `$i18n` - 包装对象 (含 locale, fallbackLocale, availableLocales)

⚠️ **注意事项**:
- `setup()` 中无法访问这些注入属性 → 必须用 `useI18n()`
- 这些注入属性与 Legacy 模式的 `$` 前缀函数**不同**
- 模板中二者可混用，但 setup 中只有 useI18n()

## 2. 全局作用域 vs 局部作用域

### 2.1 全局作用域 (默认)

```ts
// 不传参或 useScope: 'global'
const { t } = useI18n({ useScope: 'global' })
```

```ts
// 可在useI18n中覆盖/合并全局消息
const { t } = useI18n({
  useScope: 'global',
  messages: {
    'zh-CN': { component: { title: '组件标题' } }
  }
})
// 这些消息会合并到全局作用域
```

### 2.2 局部作用域

```ts
const { t } = useI18n({
  useScope: 'local',
  messages: {
    'zh-CN': { title: '局部翻译' }
  }
})
```

**选择建议**:
- **管理后台/admin**: 全局作用域 — 翻译术语统一，避免重复
- **业务组件库**: 局部作用域 — 封装独立，可复用
- **当前项目5174-admin**: 全用全局作用域，i18n定义集中在 locales/ 目录

## 3. 懒加载翻译文件 (Lazy Loading)

### 3.1 核心模式

大规模项目不应一次性加载所有locale。按需加载：

```
src/
├── locales/
│   ├── zh-CN.json
│   ├── en.json
│   └── ja.json
├── i18n.ts        ← setupI18n, loadLocaleMessages
└── router.ts      ← beforeEach 钩子中调用
```

### 3.2 实现代码

```ts
// i18n.ts
import { createI18n } from 'vue-i18n'

export const SUPPORT_LOCALES = ['zh-CN', 'en', 'ja']

export function setupI18n(options = { locale: 'zh-CN' }) {
  const i18n = createI18n({ legacy: false, ...options })
  setI18nLanguage(i18n, options.locale)
  return i18n
}

export function setI18nLanguage(i18n, locale: string) {
  // Composition API模式下locale是ref
  if (i18n.mode === 'legacy') {
    i18n.global.locale = locale
  } else {
    i18n.global.locale.value = locale
  }
  document.querySelector('html')?.setAttribute('lang', locale)
}

export async function loadLocaleMessages(i18n, locale: string) {
  // 动态import — 代码分割的关键
  const messages = await import(`./locales/${locale}.json`)
  i18n.global.setLocaleMessage(locale, messages.default)
  return nextTick()
}
```

```ts
// router.ts — vue-router 导航守卫
router.beforeEach(async (to, from, next) => {
  const locale = to.params.locale as string

  // 不支持的语言重定向
  if (!SUPPORT_LOCALES.includes(locale)) {
    return next('/zh-CN')
  }

  // 未加载则懒加载
  if (!i18n.global.availableLocales.includes(locale)) {
    await loadLocaleMessages(i18n, locale)
  }

  setI18nLanguage(i18n, locale)
  return next()
})
```

### 3.3 对当前项目的影响

**5174-admin 当前做法分析**:
- 所有locale消息可能打包在主bundle中 → 浪费带宽
- 建议改造: 懒加载非当前语言的翻译文件
- 但 5174-admin 是B端管理后台，locale切换频率低 → 优先级不高
- **短期建议**: 保持当前方式，先完成i18n迁移 (25% → 100%)
- **中期优化**: 按语言拆包 + 懒加载，减少首屏bundle

## 4. 性能优化

### 4.1 Bundle大小优化

vue-i18n 提供两个ES模块版本:

| Bundle | 内容 | 大小 | 适用场景 |
|--------|------|------|----------|
| `vue-i18n.esm-bundler.js` | 编译器 + 运行时 | 较大 (默认) | 开发环境、CSP无需 |
| `vue-i18n.runtime.esm-bundler.js` | 仅运行时 | 较小 | 预编译消息、生产环境 |

**配置方式** (vite):
```ts
// vite.config.ts
import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite'

export default defineConfig({
  plugins: [
    VueI18nPlugin({
      include: resolve(__dirname, './src/locales/**'),
    })
  ]
})
```

安装: `npm i -D @intlify/unplugin-vue-i18n`

### 4.2 Tree-Shaking 特性标志

```ts
// vite.config.ts
export default defineConfig({
  define: {
    __VUE_I18N_FULL_INSTALL__: true,   // 禁用可树摇组件/指令
    __VUE_I18N_LEGACY_API__: false,     // 禁用Legacy API (组合式API项目)
  }
})
```

**对当前项目建议**: 
- `__VUE_I18N_LEGACY_API__: false` → 5174-admin是纯Vue3组合式API
- 可减少bundle ~15-20KB

### 4.3 JIT编译 (v9.3+)

v9.3前：AOT预编译 → CSP问题、后端集成困难
v9.3+：支持JIT编译，翻译时动态编译消息

```ts
define: {
  __INTLIFY_JIT_COMPILATION__: true,      // v10+ 默认true
}
```

**v10+**: JIT编译默认开启，无需手动配置。

## 5. 大规模i18n迁移模式总结

### 5.1 当前项目改造模式 (基于handoff分析)

5174-admin 12个视图，已完成5/12 (42%)。现有模式：

```vue
<!-- 改造前 (StoreManager) -->
<template>
  <h1>门店管理</h1>
  <el-button>新增门店</el-button>
</template>

<!-- 改造后 -->
<script setup lang="ts">
import { useI18n } from 'vue-i18n'
const { t } = useI18n()
</script>

<template>
  <h1>{{ t('storeManager.title') }}</h1>
  <el-button>{{ t('storeManager.addStore') }}</el-button>
</template>
```

### 5.2 最佳实践建议

1. **统一key命名规范**: `{viewName}.{section}.{element}` 如 `storeManager.table.columns.name`
2. **提取重复文案**: 跨视图的通用按钮 (保存/取消/确认) → 放入 `common.*`
3. **先改硬编码再补充**: 先 <10min 的快速视图 (DataCenter 5→20), 再攻坚 StoreManager (~30处)
4. **批量替换技巧**: 用IDE的"Find in Files" + 正则辅助统计遗漏点
5. **测试验证**: 每个视图改造后切换语言检查

### 5.3 剩余视图优先级重排

基于handoff数据，建议顺序：

| 优先级 | 视图 | 估计t()数 | 理由 |
|--------|------|-----------|------|
| P0 | StoreManager | ~30 | 🔴 仅初始化，工作量最大 |
| P0 | DataCenter | ~15 | 🟡 5→20，快速可完成 |
| P0 | TenantManager | ~15 | 🟡 2→15 |
| P1 | FinanceCenter | ~10 | 🔴 仅初始化 |
| P1 | DashboardView | ~15 | ⬜ 未开始 |
| P1 | LoginView | ~5 | ⬜ 简单视图 |
| P2 | HRManager | ~20 | ⬜ 未开始 |
| P2 | MarketingCenter | ~15 | ⬜ 未开始 |
| P2 | SystemConfig | ~10 | ⬜ 未开始 |

**目标**: Day 4完成P0 → i18n总进度 25% → 67% (8/12)

## 6. 关键API速查

| API | 用途 | 示例 |
|-----|------|------|
| `t(key, [named], [default])` | 消息翻译 | `t('hello', { name: 'World' })` |
| `d(value, [keyOrOptions])` | 日期格式化 | `d(new Date(), 'long')` |
| `n(value, [keyOrOptions])` | 数字格式化 | `n(1000, 'currency')` |
| `rt(key)` | 原始翻译消息 | `rt('message.hello')` |
| `tm(key)` | 获取消息对象 | `tm('messages')` |
| `setLocaleMessage(locale, msg)` | 动态设置翻译 | 懒加载用 |
| `getLocaleMessage(locale)` | 获取翻译 | 调试用 |
| `mergeLocaleMessage(locale, msg)` | 合并翻译 | 模块化构建 |
| `locale` (ref) | 当前语言 | `locale.value = 'en'` |

## 7. 总结

1. **Composition API 必须 `legacy: false`** — 否则 useI18n() 不可用
2. **useI18n() 返回值直接解构使用** — t/d/n + locale/fallbackLocale
3. **大规模项目应懒加载翻译文件** — router beforeEach + 动态import
4. **生产环境优化**: runtime-only bundle + tree-shaking legacy API + JIT编译
5. **当前项目**: 维持现有模式先跑通100% i18n覆盖，后续迭代优化bundle
6. **代码组织**: locales/ 按语言分文件 + common.* 提取公共文案

---

*学习时间: ~30分钟 | 下次跟进: 应用 lazy loading 到 5174-admin 生产构建*
