# Playwright E2E测试在Monorepo中的架构设计

> 学习时间: 2026-05-15 02:45-03:20
> 来源: playwright.dev 官方文档 — Best Practices, Projects, Sharding, CI 章节

## 1. Playwright Projects — Monorepo的自然适配层

### 1.1 Project = 逻辑测试组

Playwright 的 `projects` 概念天然适配 monorepo 结构。每个 app/包 可映射为一个 project：

```ts
// playwright.config.ts (monorepo根目录)
import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './tests',
  
  projects: [
    // === 按应用分组 ===
    {
      name: '5174-admin',
      testDir: './apps/5174-admin/e2e',
      use: { baseURL: 'http://localhost:5174' },
    },
    {
      name: '5178-bsite',
      testDir: './apps/5178-bsite/e2e',
      use: { baseURL: 'http://localhost:5178' },
    },
    {
      name: '5171-mobile',
      testDir: './apps/5171-mobile/e2e',
      use: { 
        baseURL: 'http://localhost:5171',
        ...devices['iPhone 12'],  // 移动端模拟
      },
    },
    // === 可按浏览器拆分子项目 ===
    {
      name: '5174-admin-chromium',
      testDir: './apps/5174-admin/e2e',
      use: { ...devices['Desktop Chrome'] },
      dependencies: ['setup'],
    },
    {
      name: '5174-admin-firefox',
      testDir: './apps/5174-admin/e2e',
      use: { ...devices['Desktop Firefox'] },
      dependencies: ['setup'],
    },
  ],
})
```

### 1.2 按环境分组

```ts
projects: [
  {
    name: 'admin-staging',
    use: { baseURL: 'http://47.239.89.102' },
    retries: 2,
  },
  {
    name: 'admin-local',
    use: { baseURL: 'http://localhost:5174' },
    retries: 0,
  },
]
```

### 1.3 按测试类型分离

```ts
projects: [
  {
    name: 'Smoke',
    testMatch: /.*smoke\.spec\.ts/,
    retries: 0,
    timeout: 30000,
  },
  {
    name: 'Regression',
    testIgnore: /.*smoke\.spec\.ts/,
    retries: 2,
    timeout: 60000,
  },
]
```

**对当前项目建议**:
- 每个 app (admin/bsite/player/mobile) 一个 project
- 先覆盖 5178-bsite (handoff P2优先级)
- 加一个 `Smoke` project 用于部署后快速验证

## 2. 核心最佳实践

### 2.1 定位器优先级 (重要！)

```
优先级从高到低:
1. getByRole()          ← 最推荐 (语义化, 与DOM结构解耦)
2. getByLabel()         ← 表单元素
3. getByPlaceholder()   ← 输入框
4. getByText()          ← 文本内容
5. getByTestId()        ← data-testid (最后手段)
6. locator() CSS/XPath  ← 最不推荐
```

```ts
// 👍 用户视角 — 不关心DOM结构
await page.getByRole('button', { name: '提交' }).click()
await page.getByLabel('用户名').fill('admin')

// 👎 DOM耦合 — designer改class就挂了
await page.locator('button.submit-btn.el-button--primary')

// 🔗 链式定位 + 过滤
await page
  .getByRole('listitem')
  .filter({ hasText: '门店A' })
  .getByRole('button', { name: '编辑' })
  .click()
```

### 2.2 Web-First 断言

```ts
// 👍 Web-first — 自动等待条件满足
await expect(page.getByText('保存成功')).toBeVisible()
await expect(page.getByRole('button')).toBeEnabled()

// 👎 手动断言 — 不等待，立即返回
expect(await page.getByText('保存成功').isVisible()).toBe(true)
```

**自动等待机制**: Playwright 会自动等待元素可操作 (visible + enabled + stable + 无遮挡)，默认超时30s。

### 2.3 测试隔离

```ts
import { test } from '@playwright/test'

test.describe('门店管理', () => {
  // 每个test独立运行，不依赖其他test
  test.beforeEach(async ({ page }) => {
    await page.goto('/store-manager')
  })

  test('添加门店', async ({ page }) => {
    await page.getByRole('button', { name: '新增门店' }).click()
    // ...
  })

  test('编辑门店', async ({ page }) => {
    await page.getByRole('button', { name: '编辑' }).first().click()
    // ...
  })
})
```

### 2.4 避免测试第三方依赖

```ts
// 用 route API mock 外部请求
test('加载第三方数据', async ({ page }) => {
  await page.route('**/api/external/**', route => 
    route.fulfill({
      status: 200,
      body: JSON.stringify(mockData),
    })
  )
  await page.goto('/dashboard')
  // 测试自己的逻辑，不依赖外部API
})
```

## 3. 项目依赖 (Setup/Teardown)

### 3.1 全局认证共享

```ts
// playwright.config.ts
projects: [
  {
    name: 'setup',
    testMatch: /.*\.setup\.ts/,
    // 登录一次，保存状态
  },
  {
    name: '5174-admin',
    dependencies: ['setup'],  // setup先跑，通过后才跑admin
    use: { storageState: 'playwright/.auth/admin.json' },
  },
]
```

```ts
// e2e/setup/auth.setup.ts
import { test as setup } from '@playwright/test'

setup('admin登录', async ({ page }) => {
  await page.goto('/login')
  await page.getByLabel('用户名').fill('admin')
  await page.getByLabel('密码').fill('password')
  await page.getByRole('button', { name: '登录' }).click()
  await page.waitForURL('/dashboard')
  await page.context().storageState({ path: 'playwright/.auth/admin.json' })
})
```

**运行顺序**: Setup项目全部通过 → 所有依赖项目并行运行

**Teardown**: 可配置 `teardown` 在所有依赖项目完成后清理。

## 4. Sharding — CI并行加速

### 4.1 分片运行

```bash
# CI中将测试分成4片
npx playwright test --shard=1/4  # 机器1
npx playwright test --shard=2/4  # 机器2
npx playwright test --shard=3/4  # 机器3
npx playwright test --shard=4/4  # 机器4
```

### 4.2 fullyParallel 分片均衡

```ts
export default defineConfig({
  fullyParallel: true,  // 测试级别分片 (推荐!)
  // 不设置则为文件级别分片 (不均衡)
})
```

### 4.3 Blob报告合并

```ts
// playwright.config.ts
export default defineConfig({
  reporter: process.env.CI ? 'blob' : 'html',
})

// CI: 合并所有分片报告
// npx playwright merge-reports --reporter html ./all-blob-reports
```

### 4.4 GitHub Actions 完整示例

```yaml
jobs:
  e2e-tests:
    strategy:
      fail-fast: false
      matrix:
        shardIndex: [1, 2, 3, 4]
        shardTotal: [4]
    steps:
      - uses: actions/checkout@v5
      - uses: actions/setup-node@v5
      - run: npm ci
      - run: npx playwright install --with-deps
      - run: npx playwright test --shard=${{ matrix.shardIndex }}/${{ matrix.shardTotal }}
      - uses: actions/upload-artifact@v4
        with:
          name: blob-report-${{ matrix.shardIndex }}
          path: blob-report

  merge-reports:
    if: ${{ !cancelled() }}
    needs: [e2e-tests]
    steps:
      - run: npx playwright merge-reports --reporter html ./all-blob-reports
      - uses: actions/upload-artifact@v4
        with:
          name: html-report
          path: playwright-report
```

## 5. 调试与开发工具

### 5.1 Test Generator (codegen)

```bash
# 录制模式 — 操作浏览器自动生成测试代码
npx playwright codegen http://localhost:5178
```

### 5.2 VS Code Extension

- 右键测试行 → Debug Test
- 测试侧栏：可视化运行/调试/监视单个test
- Pick Locator：点击页面元素自动生成locator

### 5.3 Trace Viewer (推荐用于CI)

```bash
# 本地调试时开启trace
npx playwright test --trace on

# 查看trace (时间线 + DOM快照 + 网络请求 + Console)
npx playwright show-report
```

trace viewer 提供比截图/视频更丰富的信息，且作为PWA可分享。

### 5.4 调试命令

```bash
npx playwright test --debug            # 步入调试
npx playwright test example.spec.ts:9 --debug  # 调试特定测试
```

## 6. 针对 Sports Ant Monorepo 的实施路线

### 6.1 阶段一：基础设施 (Day 4-5, ~4h)

```bash
# 1. 安装
cd /Users/yaoyunzhong/Desktop/SPORTS\ ANT
npm i -D @playwright/test
npx playwright install

# 2. 根目录 playwright.config.ts
# 3. e2e/ 目录结构
# 4. 一个简单的 smoke test
```

```
SPORTS ANT/
├── playwright.config.ts
├── e2e/
│   ├── setup/
│   │   └── auth.setup.ts          # 全局登录
│   ├── admin/                      # 5174-admin
│   │   ├── login.spec.ts
│   │   ├── store-manager.spec.ts
│   │   └── dashboard.spec.ts
│   ├── bsite/                      # 5178-bsite (P2优先)
│   │   ├── home.spec.ts
│   │   └── navigation.spec.ts
│   ├── mobile/                     # 5171-mobile
│   └── smoke/                      # 冒烟测试
│       └── critical-path.spec.ts
└── playwright/
    └── .auth/                      # 登录状态文件
```

### 6.2 阶段二：覆盖关键路径 (Day 5-6)

**优先覆盖** (按handoff P2):
1. **5178-bsite**: 26视图响应式已100% → 先跑通 smoke (首页加载 + 导航 + 预约流程)
2. **5174-admin**: 登录 → 门店管理CRUD → 仪表板加载
3. **player端**: 基础播放验证

### 6.3 阶段三：CI集成 (Day 7+)

```yaml
# .github/workflows/e2e.yml
name: E2E Tests
on:
  push:
    branches: [main]
  schedule:
    - cron: '0 6 * * *'  # 每日06:00 UTC
```

### 6.4 推荐配置

```ts
// playwright.config.ts for Sports Ant
import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 4 : undefined,
  reporter: process.env.CI ? 'blob' : 'html',
  
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:5173',
    trace: 'on-first-retry',
  },

  projects: [
    { name: 'setup', testMatch: /.*\.setup\.ts/ },
    
    // Desktop browsers for admin/bsite
    {
      name: 'admin-chromium',
      testDir: './e2e/admin',
      use: { ...devices['Desktop Chrome'] },
      dependencies: ['setup'],
    },
    {
      name: 'bsite-chromium',
      testDir: './e2e/bsite',
      use: { ...devices['Desktop Chrome'] },
    },
    
    // Mobile
    {
      name: 'mobile-chromium',
      testDir: './e2e/mobile',
      use: { ...devices['Pixel 5'] },
    },
    
    // Smoke (fast, no retry)
    {
      name: 'smoke',
      testMatch: /.*smoke\.spec\.ts/,
      retries: 0,
      timeout: 30000,
    },
  ],
  
  // 可选：Web server 自动启动
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:5173',
    reuseExistingServer: !process.env.CI,
  },
})
```

## 7. 关键API速查

| API | 用途 |
|-----|------|
| `page.goto(url)` | 导航到页面 |
| `page.getByRole(role, options)` | 语义化定位器 (最推荐) |
| `page.getByLabel(text)` | 表单标签定位 |
| `page.getByText(text)` | 文本内容定位 |
| `page.getByTestId(id)` | data-testid 定位 |
| `locator.click()` | 点击元素 |
| `locator.fill(text)` | 输入文本 |
| `locator.filter(options)` | 过滤匹配元素 |
| `page.route(url, handler)` | 拦截/模拟网络请求 |
| `expect(locator).toBeVisible()` | Web-first 可见性断言 |
| `expect(locator).toHaveText(text)` | 文本内容断言 |
| `page.context().storageState()` | 保存登录状态 |
| `page.waitForURL(url)` | 等待URL变化 |
| `page.screenshot()` | 截图 |
| `test.beforeEach()` | 每个测试前执行 |
| `test.describe()` | 测试分组 |

## 8. 总结

1. **Projects 天然映射 monorepo 子应用** — 每个app一个project，独立baseURL/浏览器
2. **优先用语义化定位器** — getByRole > getByLabel > getByText > getByTestId，避免CSS选择器
3. **Web-first 断言自动等待** — `expect().toBeVisible()` 而不是 `isVisible()`
4. **Setup/Dependencies 实现登录状态共享** — 避免每个test重复登录
5. **Sharding + Blob报告合并** — CI 4分片并行 → 合并HTML报告
6. **当前项目**：先基建（配置 + smoke），再覆盖5178-bsite关键路径，最后CI集成
7. **fullyParallel: true** — 测试级分片比文件级更均衡

---

*学习时间: ~35分钟 | 下次跟进: 搭建 e2e/ 目录 + playwright.config.ts*
