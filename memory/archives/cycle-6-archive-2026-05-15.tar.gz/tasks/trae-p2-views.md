# 🐜 树哥任务指令 — 持续开发 P2

> 自动执行，无需等待龙虾哥指令

## 前置
```bash
cd ~/Desktop/SPORTS ANT && git pull && pnpm install
```

## 任务1: BSite 首页丰富化 🔴
修改 `apps/8004-bsite/src/views/HomeView.vue`:
- Hero: 大标题 + 副标题 + CTA按钮 + 渐变背景
- Features: 4卡片网格 (AI/盲盒/NFT/支付) 每卡片有icon+标题+描述
- 响应式: 手机1列→Pad 2列→桌面4列
- 全用 design-tokens.css 变量

## 任务2: Admin 其余10个视图填充 🟡
每个视图替换 `h1+p` 占位符为有意义的布局:
- MemberView: 会员等级展示(5级卡片) + 会员列表表格
- BookingView: 预约列表表格 + 状态标签
- MallView: 商品卡片网格(4个盲盒示例) + 成本透明展示
- NFTView: NFT列表表格 + 流转记录
- KOCView: KOC等级卡片(3级) + 佣金规则
- HardwareView: 设备在线状态列表
- FinanceView: 税率表格(8国) + 收入概览
- MarketingView: 活动卡片 + 营销渠道
- TenantView: 租户信息卡片 + 品牌配置
- StaffView: 8岗位角色卡片 + 权限说明
全部用 design-tokens.css + Element Plus 组件

## 完成
- git add -A && git commit -m "feat(views): 丰富化15视图 — BSite首页+Admin10视图" && git push
- 测试不破坏，TS零错误
