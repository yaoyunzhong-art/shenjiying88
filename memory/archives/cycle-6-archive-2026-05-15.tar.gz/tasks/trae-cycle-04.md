# 🐜 树哥任务指令 — Cycle 4

> 龙虾专家团队设计 | 📚 学习+设计 Cycle
> 2026-05-15 | 🎨 设计美工队 + 🏗️ 架构师队联合出品

---

## 前置检查

```bash
cd ~/Desktop/SPORTS ANT
git pull origin main
pnpm install
```

---

## 学习笔记参考（必读）

- 📘 `~/.openclaw/workspace/learning/css-custom-properties-design-tokens-2026-05-15.md`
  — CSS Token 三层架构 + Element Plus 暗色模式 + FOUC 防护
- 📗 `~/.openclaw/workspace/knowledge/design/Sci-Fi-Design-System.md`
  — 设计规范全量（色板/字体/间距/组件/暗色/logo）

---

## 任务清单

### 任务1: 创建设计 Token 三层体系 🔴 P0

**三层 Token 架构**（从上到下，每层引用上层）:

```
L1  Primitive   →  design-tokens.css     (原始色值)
L2  Semantic    →  theme-light.css        (亮色语义)
                   theme-dark.css         (暗色语义)
L3  Component   →  component-tokens.css   (组件引用)
```

**文件**: `packages/shared-styles/design-tokens.css`（L1 Primitive）

```css
:root {
  /* === 色板（10级色阶 × 品牌色系）=== */
  --color-blue-900: #1A1A2E;
  --color-blue-500: #0F3460;
  --color-blue-100: #E8EEF5;

  --color-red-500: #E94560;
  --color-red-400: #FF6B6B;

  --color-green-500: #10B981;
  --color-amber-500: #F59E0B;
  --color-red-error: #EF4444;

  /* === 字体尺度 === */
  --text-xs: 12px;  --text-sm: 14px;
  --text-base: 16px; --text-lg: 18px;
  --text-xl: 20px;  --text-2xl: 24px;
  --text-3xl: 32px;

  /* === 间距（4px base）=== */
  --space-xs: 4px;   --space-sm: 8px;
  --space-md: 16px;  --space-lg: 24px;
  --space-xl: 32px;  --space-xxl: 48px;

  /* === 圆角 === */
  --radius-sm: 6px;   --radius-md: 10px;
  --radius-lg: 16px;  --radius-xl: 24px;

  /* === 阴影 === */
  --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
  --shadow-md: 0 4px 12px rgba(0,0,0,0.08);
  --shadow-lg: 0 8px 24px rgba(0,0,0,0.12);
  --shadow-glow: 0 0 20px rgba(233,69,96,0.3);

  /* === 过渡 === */
  --transition-base: 300ms ease;
}
```

**文件**: `packages/shared-styles/theme-light.css`（L2 亮色语义）

```css
:root,
[data-theme="light"] {
  --color-surface:        #FFFFFF;
  --color-bg:             #F5F7FA;
  --color-border:         #E4E7ED;
  --color-text:           #1A1A2E;
  --color-text-secondary: #909399;
}
```

**文件**: `packages/shared-styles/theme-dark.css`（L2 暗色语义）

```css
[data-theme="dark"] {
  --color-surface:        #16213E;
  --color-bg:             #0F0F1A;
  --color-border:         #2A2A4A;
  --color-text:           #E4E7ED;
  --color-text-secondary: #909399;
}
```

**文件**: `packages/shared-styles/component-tokens.css`（L3 组件引用）

```css
/* 侧边栏 */
--sidebar-bg:        var(--color-blue-900);
--sidebar-width:     240px;
--sidebar-collapsed: 64px;

/* Header */
--header-height:     56px;

/* 按钮 */
--btn-primary-bg:    var(--color-red-500);
--btn-primary-hover: var(--color-red-400);
```

**文件**: `packages/shared-styles/index.css`（汇总入口）

```css
@import './design-tokens.css';
@import './theme-light.css';
@import './theme-dark.css';
@import './component-tokens.css';
@import './responsive.css';
```

**门禁**: 
- `packages/shared-styles/index.css` 可被引入无报错
- Admin dev server → 浏览器 DevTools 能看到 `--color-*` 变量

---

### 任务2: 构建 Admin 布局模板 🔴 P0

**文件**: `apps/8001-admin/src/layouts/AdminLayout.vue`

**布局 HTML 骨架**:
```html
<template>
  <div class="admin-layout" :class="{ collapsed: sidebarCollapsed }">
    <!-- 左侧边栏 -->
    <aside class="admin-sidebar">
      <div class="sidebar-logo">
        <span class="logo-icon">🐜</span>
        <span v-show="!sidebarCollapsed" class="logo-text">蚂蚁数娱</span>
      </div>
      <el-menu
        :default-active="currentRoute"
        :collapse="sidebarCollapsed"
        background-color="var(--sidebar-bg)"
        text-color="#bfcbd9"
        active-text-color="var(--color-red-500)"
        router
      >
        <!-- 遍历 routes 生成菜单项 -->
      </el-menu>
      <div class="sidebar-footer">
        <!-- 用户头像 + 名称 -->
      </div>
    </aside>

    <!-- 右侧主区 -->
    <div class="admin-main">
      <header class="admin-header">
        <button class="hamburger" @click="toggleSidebar">☰</button>
        <el-breadcrumb />
        <div class="header-actions">
          <ThemeToggle />
          <LangSwitch />
          <UserAvatar />
        </div>
      </header>
      <main class="admin-content">
        <router-view />
      </main>
    </div>
  </div>
</template>
```

**CSS 关键样式**（使用 token 变量）:
```css
.admin-sidebar {
  width: var(--sidebar-width);
  background: var(--sidebar-bg);
  transition: width var(--transition-base);
}
.admin-layout.collapsed .admin-sidebar {
  width: var(--sidebar-collapsed);
}
.admin-header {
  height: var(--header-height);
  border-bottom: 1px solid var(--color-border);
  background: var(--color-surface);
}
.admin-content {
  padding: var(--space-lg);
  background: var(--color-bg);
  min-height: calc(100vh - var(--header-height));
}
```

**技术要点**:
- `el-menu` 使用 `router` 属性实现路由联动
- `:default-active` 绑定 `route.path` 实现高亮
- 侧边栏折叠用 `ref(sidebarCollapsed)` + CSS transition
- 移动端默认折叠 (`@media (max-width: 768px)`)
- 所有颜色/间距使用 `var(--*)` 引用，不写死

**门禁**: admin dev → 11路由可切换 → 折叠动画流畅 → 移动端汉堡菜单

---

### 任务3: 实现暗色/亮色主题切换 🔴 P0

**文件1**: `packages/shared-styles/theme-switch.ts`

```ts
type Theme = 'light' | 'dark';

const STORAGE_KEY = 'sports-ant-theme';

export function getStoredTheme(): Theme {
  if (typeof localStorage === 'undefined') return 'light';
  return (localStorage.getItem(STORAGE_KEY) as Theme) || 'light';
}

export function applyTheme(theme: Theme): void {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem(STORAGE_KEY, theme);

  // 🔑 联动 Element Plus 暗色模式
  // Element Plus 暗色通过 html.dark class 驱动
  // 我们同时设置 data-theme + class 以兼容两套系统
  if (theme === 'dark') {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
}

export function toggleTheme(): Theme {
  const next = getStoredTheme() === 'light' ? 'dark' : 'light';
  applyTheme(next);
  return next;
}
```

**文件2**: `apps/8001-admin/index.html` — FOUC 防护（关键！）

```html
<head>
  <!-- ⚠️ 第一个 script，同步执行，阻止白屏闪烁 -->
  <script>
    (function() {
      var theme = localStorage.getItem('sports-ant-theme') || 'light';
      document.documentElement.setAttribute('data-theme', theme);
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      }
    })();
  </script>
  <!-- 之后才是 CSS/JS 加载 -->
</head>
```

**文件3**: `apps/8001-admin/src/components/ThemeToggle.vue`

```vue
<template>
  <button class="theme-toggle" @click="toggle" :title="t('theme.toggle')">
    <span v-if="theme === 'light'">🌙</span>
    <span v-else>☀️</span>
  </button>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { getStoredTheme, toggleTheme } from 'shared-styles/theme-switch';
const theme = ref(getStoredTheme());
const toggle = () => { theme.value = toggleTheme(); };
</script>
```

**门禁**: 
- 刷新页面 → 主题保持 → 无白屏/闪烁
- 点击切换 → Admin + Element Plus 组件同步变暗/亮
- Element Plus `el-menu` / `el-card` 等组件正确响应暗色模式

**Element Plus 暗色模式启用**（`admin/src/main.ts`）:
```ts
// 必须在注册 ElementPlus 之前引入
import 'element-plus/theme-chalk/dark/css-vars.css';
```

---

### 任务4: 升级 DashboardView 为 KPI 看板 🔴 P0

**文件**: `apps/8001-admin/src/views/DashboardView.vue`

**替换当前** `h1 + p` 占位为完整看板:

```html
<template>
  <div class="dashboard">
    <h2 class="page-title">{{ t('dashboard.overview') }}</h2>

    <!-- KPI 卡片行 -->
    <div class="kpi-grid">
      <div class="kpi-card" v-for="kpi in kpis" :key="kpi.key">
        <div class="kpi-label">{{ t(`dashboard.kpi.${kpi.key}`) }}</div>
        <div class="kpi-value">{{ kpi.value }}</div>
        <div class="kpi-trend" :class="kpi.trend > 0 ? 'up' : 'down'">
          {{ kpi.trend > 0 ? '↑' : '↓' }} {{ Math.abs(kpi.trend) }}%
        </div>
      </div>
    </div>

    <!-- 两栏信息区 -->
    <div class="dashboard-grid">
      <div class="info-card">
        <h3>{{ t('dashboard.deviceStatus') }}</h3>
        <div class="device-status">
          <span class="status-dot online"></span>
          {{ t('dashboard.devicesOnline', { online: 23, total: 25 }) }}
        </div>
      </div>
      <div class="info-card">
        <h3>{{ t('dashboard.recentBookings') }}</h3>
        <ul class="booking-list">
          <li v-for="b in recentBookings" :key="b.id">
            <span>{{ b.customer }}</span>
            <span>{{ b.time }}</span>
            <el-tag size="small" :type="b.statusType">{{ b.status }}</el-tag>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
```

**CSS 使用 token**:
```css
.kpi-card {
  background: var(--color-surface);
  border-radius: var(--radius-md);
  padding: var(--space-lg);
  box-shadow: var(--shadow-sm);
}
.kpi-value {
  font-size: var(--text-2xl);
  font-weight: 700;
  color: var(--color-text);
}
.kpi-trend.up { color: var(--color-green-500); }
.kpi-trend.down { color: var(--color-red-error); }
```

**响应式**: `kpi-grid` → 桌面4列 / Pad 2列 / 手机1列

**门禁**: 4 KPI卡 + 2信息区正常 → 暗色/亮色切换 → 响应式断点正常

---

### 任务5: 注册后端剩余 4 个 Controller 🔴 P0

**文件**: `backend/gateway/src/app.module.ts`

**检查**（先看已注册了哪些）:
```bash
grep -n 'Module\|Controller' backend/gateway/src/app.module.ts
```

**添加**（在现有 imports 中追加）:
```ts
// 确保这4个模块被导入/注册
import { NFTModule } from '../../nft/nft.module';        // 或 nft.controller
import { MallModule } from '../../mall/mall.module';
import { HardwareModule } from '../../hardware/hardware.module';
import { KOCModule } from '../../koc/koc.module';
```

**注意**: 先检查 backend 目录结构，确认是用 NestJS Module 模式还是直接 Controller 注册模式。根据实际情况调整。

**验证**:
```bash
cd backend && npx nest start
# 检查输出：应有 7 个路由组注册
```

**门禁**: 后端 :3000 启动 → 7 Controller / 路由组全部注册 → curl 返回正常

---

## 完成标准

- [ ] 5 个任务全部完成
- [ ] `pnpm exec jest` → 53/53+ ✅
- [ ] `npx vue-tsc --noEmit` → 零新增错误
- [ ] Admin dev → 布局 + 主题切换 + 看板正常
- [ ] 暗色/亮色切换：刷新保持 + 无白屏 + Element Plus 联动
- [ ] 后端 :3000 → 7 路由组
- [ ] `git push origin main` → 成功
- [ ] Commit: `feat(design): 设计系统搭建 — Token三层体系+布局+主题+看板+4Controller`

---

## 参考文档

- 📘 学习笔记: `~/.openclaw/workspace/learning/css-custom-properties-design-tokens-2026-05-15.md`
- 📗 设计规范: `~/.openclaw/workspace/knowledge/design/Sci-Fi-Design-System.md`
- 已有CSS: `packages/shared-styles/responsive.css`
- Element Plus: [Dark Mode](https://element-plus.org/en-US/guide/dark-mode) + [Theming](https://element-plus.org/en-US/guide/theming)
- 后端: `backend/` 下各模块目录
