# 🐜 树哥任务指令 — 持续开发 P3

> 自动执行，无需等待

## 前置
```bash
cd ~/Desktop/SPORTS ANT && git pull && pnpm install
```

## 任务1: 为Admin视图连接真实API 🔴
修改 admin views，从 mock 数据改为 API 调用:
- 使用 fetch 从 http://localhost:3000/api/v1/* 获取数据
- DashboardView: /api/v1/health/stats 显示真实状态
- MemberView: /api/v1/members 显示会员列表
- BookingView: /api/v1/bookings 显示预约
- MallView: /api/v1/mall/blindboxes 显示盲盒
- HardwareView: /api/v1/hardware 显示设备
- KOCView: /api/v1/koc 显示KOC

每个视图加 loading 和 error 状态处理

## 任务2: 品牌视觉升级 🟡
如果有 Desktop 上的 运动蚂蚁VI系统 图片可访问:
- 提取主色调应用到 design-tokens.css
- 制作 favicon
如果没有图片访问权限，保持现有设计

## 任务3: 阿里云部署最新版本 🚀
```bash
cd ~/Desktop/SPORTS ANT && bash quick-deploy.sh
curl -s -o /dev/null -w "%{http_code}" http://47.239.89.102
```

## 完成
git add -A && git commit -m "feat: API连接+品牌+云部署" && git push
测试不破坏，TS零错误
