# 🐜 树哥改进指令 — Cycle 5 技术评审修复

> 📅 2026-05-15 | 🔍 龙虾哥审查 | ⏱️ 预计 45min
> 修复 3 P0 + 5 P1，完成后再提交

---

## ⚡ 快速自检

```bash
cd ~/Desktop/SPORTS\ ANT
git pull origin main
pnpm install
```

---

## 🔴 P0 — 阻塞（15min，必须先修）

### P0#1: FOUC 白屏闪烁防护 (5min) 🔴

**文件**: `apps/8001-admin/index.html`

**问题**: 暗色用户刷新闪白屏。`main.ts` 的 `initTheme()` 在 Vue 挂载后才跑，太晚。

**修复**: 在 `<head>` 第一行（Google Fonts `<link>` 之前）插入同步 script：

```html
<head>
  <meta charset="UTF-8" />
  <script>
    (function(){
      var t=localStorage.getItem('sports-ant-theme')||'light';
      document.documentElement.setAttribute('data-theme',t);
      if(t==='dark')document.documentElement.classList.add('dark');
    })();
  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>蚂蚁数娱 · Sports Ant</title>
  <!-- Google Fonts ... -->
</head>
```

**验证**: `localStorage.setItem('sports-ant-theme','dark')` → 刷新 → 无白屏闪烁

---

### P0#2: HealthController 添加 /ready /live 端点 (5min) 🔴

**文件**: `backend/gateway/src/health.controller.ts`

**修复**:

```ts
import { Controller, Get } from '@nestjs/common';

@Controller('health')
export class HealthController {
  @Get()
  check() { return { status: 'ok', uptime: process.uptime(), timestamp: new Date() }; }

  // ⬇️ 新增
  @Get('ready')
  ready() { return { status: 'ready' }; }

  @Get('live')
  live() { return { status: 'alive' }; }

  @Get('stats')
  stats() {
    return { tests: 115, e2e: 40, ts: 0, controllers: 7 };
  }
}
```

**验证**: `curl http://localhost:3000/api/v1/health/ready` → `{"status":"ready"}`

---

### P0#3: 创建 shared-styles/index.ts 入口 (5min) 🔴

**文件**: `packages/shared-styles/index.ts` (新建)

```ts
/**
 * @sports-ant/shared-styles — 设计系统统一入口
 * 2026-05-15
 */

// 所有 CSS 文件通过 package.json exports 按需引入
// This file serves as the package main entry for tooling resolution
export {}
```

**验证**: `node -e "require('@sports-ant/shared-styles')"` 不报错（或 TS 编辑器无红色下划线）

---

## 🟡 P1 — 质量提升（30min）

### P1#1: AdminLayout 硬编码中文 → i18n (10min) 🟡

**文件**: `apps/8001-admin/src/layouts/AdminLayout.vue`

**替换清单**:

| 行号 | 当前硬编码 | 替换为 |
|------|-----------|--------|
| L67 | `管理员` | `{{ t('user.admin') }}` |
| L68 | `超级管理员` | `{{ t('user.superAdmin') }}` |
| L135 | `个人中心` | `{{ t('menu.profile') }}` |
| L139 | `系统设置` | `{{ t('menu.settings') }}` |
| L143 | `退出登录` | `{{ t('menu.logout') }}` |

**如果 i18n JSON 缺少这些 key，在 `zh.json` 和 `en.json` 中加入**:

```json
// zh.json
{
  "user": { "admin": "管理员", "superAdmin": "超级管理员" },
  "menu": { "profile": "个人中心", "settings": "系统设置", "logout": "退出登录" }
}
// en.json
{
  "user": { "admin": "Admin", "superAdmin": "Super Admin" },
  "menu": { "profile": "Profile", "settings": "Settings", "logout": "Logout" }
}
```

---

### P1#2: 拆分 design-tokens.css (10min) 🟡

**目标**: 分离 token 定义、全局 reset、工具类

**新建文件**: `packages/shared-styles/reset.css`

```css
/* Global Reset */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { font-family: var(--font-sans); font-size: var(--text-base); line-height: var(--leading-normal); color: var(--text-primary); background-color: var(--bg-base); -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
body { min-height: 100vh; background-color: var(--bg-base); color: var(--text-primary); transition: background-color var(--transition-base), color var(--transition-base); font-feature-settings: 'cv11', 'ss01'; }
a { color: var(--brand-accent); text-decoration: none; transition: color var(--transition-fast); }
a:hover { color: var(--color-accent-600); }
```

**新建文件**: `packages/shared-styles/utilities.css`

```css
/* Utility Classes */
.tnum, [data-tnum] { font-feature-settings: 'tnum'; }
.sa-kpi-grid { display: grid; gap: var(--space-md); grid-template-columns: repeat(1, 1fr); }
@media (min-width: 576px)  { .sa-kpi-grid { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 1200px) { .sa-kpi-grid { grid-template-columns: repeat(4, 1fr); } }
.focus-ring:focus-visible { outline: var(--ring-width) solid var(--ring-color); outline-offset: var(--ring-offset); }
.glass { background: var(--glass-bg); backdrop-filter: blur(var(--blur-md)); -webkit-backdrop-filter: blur(var(--blur-md)); border: 1px solid var(--glass-border); }
```

**修改**: `design-tokens.css` — 删除 13 (全局重置) + 15/16/17 (工具类) 三个 section，仅保留 token 定义 + 暗色主题

**更新**: `apps/8001-admin/src/main.ts` 引入顺序:
```ts
import '@sports-ant/shared-styles/reset.css'
import '@sports-ant/shared-styles/design-tokens.css'
import '@sports-ant/shared-styles/utilities.css'
import '@sports-ant/shared-styles/animations.css'
```

**更新**: `packages/shared-styles/package.json` exports 追加:
```json
"./reset.css": "./reset.css",
"./utilities.css": "./utilities.css"
```

---

### P1#3: DashboardView 拆分子组件 (10min) 🟡

**新建**: `apps/8001-admin/src/components/KpiCard.vue`

```vue
<template>
  <article class="kpi-card" :class="[`kpi-card--${type}`, 'card-hover']">
    <div class="kpi-card__indicator" />
    <div class="kpi-card__inner">
      <div class="kpi-card__header">
        <span class="kpi-card__icon">{{ icon }}</span>
        <span class="kpi-card__label">{{ label }}</span>
      </div>
      <div class="kpi-card__value">
        <span class="kpi-card__number">{{ value }}</span>
      </div>
      <div class="kpi-card__footer">
        <span class="kpi-card__trend" :class="trendUp ? 'kpi-card__trend--up' : 'kpi-card__trend--down'">
          <span class="trend-arrow">{{ trendUp ? '↑' : '↓' }}</span> {{ Math.abs(trend) }}%
        </span>
        <span class="kpi-card__vs">{{ vsText }}</span>
      </div>
    </div>
  </article>
</template>

<script setup lang="ts">
defineProps<{
  type: string; icon: string; label: string;
  value: string; trend: number; trendUp: boolean; vsText: string;
}>()
</script>
```

**使用**: DashboardView 模板中:
```html
<KpiCard type="revenue" icon="💰" label="今日营收" value="¥12,800"
  :trend="12" :trend-up="true" vs-text="较昨日 +¥1,371" />
<KpiCard type="traffic" icon="👥" label="今日客流" value="186"
  :trend="8" :trend-up="true" vs-text="较昨日 +14人" />
<KpiCard type="verify" icon="✅" label="核销数" value="142"
  :trend="3" :trend-up="false" vs-text="较昨日 -4单" />
<KpiCard type="koc" icon="🚀" label="KOC贡献" value="¥2,400"
  :trend="22" :trend-up="true" vs-text="较昨日 +¥433" />
```

**移动**: 从 `DashboardView.vue` CSS 移动 KPI 卡片样式到 `KpiCard.vue` `<style scoped>`

---

## ✅ 完成标准

- [ ] 3 个 P0 全部修复
- [ ] `pnpm exec jest` → 115/115 ✅
- [ ] `npx vue-tsc --noEmit` → 零错误
- [ ] Admin dev → 暗色刷新无白屏
- [ ] `curl localhost:3000/api/v1/health/ready` → `{"status":"ready"}`
- [ ] `curl localhost:3000/api/v1/health/live` → `{"status":"alive"}`
- [ ] `ls packages/shared-styles/index.ts` → 存在
- [ ] 中文硬编码已替换为 i18n
- [ ] `git push origin main` → 成功
- [ ] Commit: `fix(review): Cycle 5 评审修复 — FOUC+health端+i18n硬编码+tokens拆分`
